# Simple Tutorial Package

This is a very simple package with the purpose of learning how to publish a package to PyPi.

I am following the [Python.org Packaging Tutorial]("https://packaging.python.org/en/latest/tutorials/packaging-projects/")

## Contents

This package is very simple.
The package is called "very_simple_backage_braveGrumpy"

The only functionality is a class called `Arithmetic`, which adds and multiplies.

It is written to be extendable into factorials. 

## Changelog

This is where I plan on changing things after publishing.